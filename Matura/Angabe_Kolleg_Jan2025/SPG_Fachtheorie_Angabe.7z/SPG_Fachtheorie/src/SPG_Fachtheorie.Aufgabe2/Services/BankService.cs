﻿using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPG_Fachtheorie.Aufgabe2.Services
{
    public class BankService
    {
        private readonly BankContext _db;

        public BankService(BankContext db)
        {
            _db = db;
        }

        public List<Kunde> SchlechteKunden(int bonitaet, int prozentsatz)
        {
            throw new NotImplementedException();
        }

        public int UeberweisungAnlegen(int auftraggeberKonto, int empfaengerKonto, string verwendungszweck, decimal betrag, DateTime datum)
        {
            throw new NotImplementedException();
        }
    }
}
