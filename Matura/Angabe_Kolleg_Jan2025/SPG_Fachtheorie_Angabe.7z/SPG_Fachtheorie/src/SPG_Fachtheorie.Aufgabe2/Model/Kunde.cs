﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Kunde
    {
        public Kunde(Ort ort, string vorname, string nachname, string strasse, int hausnummer, int bonitaet, Mitarbeiter betreuer)
        {
            Vorname = vorname;
            Nachname = nachname;
            Strasse = strasse;
            Hausnummer = hausnummer;
            Ort = ort;
            Bonitaet = bonitaet;
            Betreuer = betreuer;
        }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        protected Kunde() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        public int Id { get; private set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }
        public string Strasse { get; set; }
        public int Hausnummer { get; set; }
        public Ort Ort { get; set; }
        public int Bonitaet { get; set; }
        public Mitarbeiter Betreuer { get; set; }
        public List<Konto> Konten { get; set; } = new();
    }
}
