﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Ort
    {
        public Ort(int postleitzahl, string stadt, string bundesland)
        {
            Postleitzahl = postleitzahl;
            Stadt = stadt;
            Bundesland = bundesland;
        }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        protected Ort() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Postleitzahl { get; set; }
        public string Stadt { get; set; }
        public string Bundesland { get; set; }
    }
}
