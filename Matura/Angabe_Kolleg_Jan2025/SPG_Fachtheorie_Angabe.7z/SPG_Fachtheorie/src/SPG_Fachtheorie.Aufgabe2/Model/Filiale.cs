﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Filiale
    {
        public Filiale(int filialnummer, string filialbezeichnung, DateTime eroeffnung, string strasse, int hausnummer, Ort ort, Mitarbeiter? filialleiter = null)
        {
            Filialnummer = filialnummer;
            Filialbezeichnung = filialbezeichnung;
            Eroeffnung = eroeffnung;
            Strasse = strasse;
            Hausnummer = hausnummer;
            Ort = ort;
            Filialleiter = filialleiter;
        }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        protected Filiale() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Filialnummer { get; set; }
        public string Filialbezeichnung { get; set; }
        public DateTime Eroeffnung { get; set; }
        public string Strasse { get; set; }
        public int Hausnummer { get; set; }
        public Ort Ort { get; set; }
        public Mitarbeiter? Filialleiter { get; set; }
        public List<Mitarbeiter> Mitarbeiter { get; set; } = new();
    }
}
