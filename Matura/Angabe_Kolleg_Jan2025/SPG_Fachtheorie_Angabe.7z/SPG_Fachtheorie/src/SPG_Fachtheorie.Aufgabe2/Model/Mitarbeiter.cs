﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Mitarbeiter
    {
        public Mitarbeiter(int personalnummer, Ort ort, string vorname, string nachname, string strasse, int hausnummer, int wochenarbeitszeit, Mitarbeiterart mitarbeiterkategorie, Filiale filiale)
        {
            Personalnummer = personalnummer;
            Vorname = vorname;
            Nachname = nachname;
            Strasse = strasse;
            Hausnummer = hausnummer;
            Ort = ort;
            Wochenarbeitszeit = wochenarbeitszeit;
            Mitarbeiterkategorie = mitarbeiterkategorie;
            Filiale = filiale;
        }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        protected Mitarbeiter() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Personalnummer { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }
        public string Strasse { get; set; }
        public int Hausnummer { get; set; }
        public Ort Ort { get; set; }
        public int Wochenarbeitszeit { get; set; }
        public Mitarbeiterart Mitarbeiterkategorie { get; set; }
        public Filiale Filiale { get; set; }
        public List<Kunde> Kunden { get; set; } = new();
    }
}
