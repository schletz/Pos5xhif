﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Ueberweisung
    {
        public Ueberweisung(Konto auftraggeber, Konto empfaenger, string verwendungszweck, decimal betrag, DateTime datum, Status status)
        {
            Auftraggeber = auftraggeber;
            Empfaenger = empfaenger;
            Verwendungszweck = verwendungszweck;
            Betrag = betrag;
            Datum = datum;
            Status = status;
        }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        protected Ueberweisung() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        public int Id { get; private set; }
        public Konto Auftraggeber { get; set; }
        public Konto Empfaenger { get; set; }
        public string Verwendungszweck { get; set; }
        public decimal Betrag { get; set; }
        public DateTime Datum { get; set; }
        public Status Status { get; set; }
    }
}
