﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Konto
    {
        public Konto(int kontonummer, Kunde kunde, decimal kontostand, decimal ueberziehungsrahmen)
        {
            Kontonummer = kontonummer;
            Kunde = kunde;
            Kontostand = kontostand;
            Ueberziehungsrahmen = ueberziehungsrahmen;
        }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        protected Konto() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Kontonummer { get; set; }
        public Kunde Kunde { get; set; }
        public decimal Kontostand { get; set; }
        public decimal Ueberziehungsrahmen { get; set; }
    }
}
