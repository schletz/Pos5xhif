using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Services;
using System;
using System.Linq;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe2.Test
{
    public class BankTests
    {
        private BankContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder()
                .UseSqlite(@"Data Source=bank.db")
                .Options;

            var db = new BankContext(options);
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
            db.Seed();
            return db;
        }

        [Fact]
        public void CreateDatabaseTest()
        {
            var db = GetDbContext();
            db.ChangeTracker.Clear();
            Assert.True(db.Ueberweisungen.Any());
        }

        [Fact]
        public void ListBadCustomersTest()
        {
            var db = GetDbContext();
            var service = new BankService(db);
            var customerIds = service.SchlechteKunden(2, 80).Select(c => c.Id).ToArray<int>();
            Assert.True(customerIds.Length == 3);
            Assert.Contains(10, customerIds);
            Assert.Contains(12, customerIds);
            Assert.Contains(65, customerIds);
        }

        [Fact]
        public void ShouldThrowException_WhenInvalidTransferorAccount()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }
        [Fact]
        public void ShouldThrowException_WhenInvalidRecipientAccount()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }
        [Fact]
        public void ShouldThrowException_WhenPurposeTooLong()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }
        [Fact]
        public void ShouldThrowException_WhenLimitIsExceeded()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }
        [Fact]
        public void ShouldReturnTransferId_WhenParametersAreValid()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }
    }
}