﻿using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;

namespace SPG_Fachtheorie.Aufgabe3.RazorPages.Pages
{
    public class IndexModel : PageModel
    {
        private readonly BankContext _db;

        public IndexModel(BankContext db)
        {
            _db = db;
        }

        public void OnGet()
        {
        }
    }
}