using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe1.Infrastructure;
using System;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe1.Test
{
    public class Aufgabe1Test
    {
        private ProductContext GetEmptyDbContext()
        {
            var options = new DbContextOptionsBuilder()
                .UseSqlite(@"Data Source=product.db")
                .Options;

            var db = new ProductContext(options);
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
            return db;
        }

        // Creates an empty DB in C:\Scratch\Aufgabe1_Test\Debug\net6.0\product.db
        [Fact]
        public void CreateDatabaseTest()
        {
            using var db = GetEmptyDbContext();
        }

        [Fact]
        public void AddInsuranceSuccessTest()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }

        [Fact]
        public void ProductDiscriminatorSuccessTest()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }

        [Fact]
        public void AddTransactionSuccessTest()
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }
    }
}