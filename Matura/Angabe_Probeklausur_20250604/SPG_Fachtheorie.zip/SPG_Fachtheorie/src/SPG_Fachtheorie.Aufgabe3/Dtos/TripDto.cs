﻿namespace SPG_Fachtheorie.Aufgabe3.Dtos
{
    // TODO: Füge hier benötigte Properties ein.
    public record TripDto();

}
