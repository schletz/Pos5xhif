﻿using System.ComponentModel.DataAnnotations;

namespace SPG_Fachtheorie.Aufgabe3.Commands
{
    // TODO: Füge hier benötigte Properties und ggf. Validierungen ein.
    public record UpdateTripCommand();
}
