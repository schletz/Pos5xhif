﻿using System;
using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public class Invoice
    {
        // TODO: Füge hier benötigte Properties und Konstruktoren ein.
    }

}