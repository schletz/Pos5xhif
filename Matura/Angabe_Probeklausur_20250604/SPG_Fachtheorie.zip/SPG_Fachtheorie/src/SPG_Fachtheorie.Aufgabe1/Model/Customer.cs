﻿using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe1.Model
{

    public class Customer
    {
        // TODO: Füge hier benötigte Properties und Konstruktoren ein.
    }

}