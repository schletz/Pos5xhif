﻿using System;

namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public enum CustomerType 
    {
        // TODO: Füge hier benötigte Felder ein.
    }

}