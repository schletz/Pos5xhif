﻿using Microsoft.EntityFrameworkCore;

namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public class InvoiceItem
    {
        // TODO: Füge hier benötigte Properties und Konstruktoren ein.
    }

}