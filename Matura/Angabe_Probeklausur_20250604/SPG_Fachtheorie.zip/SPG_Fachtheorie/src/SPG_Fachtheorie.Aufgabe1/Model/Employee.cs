﻿namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public class Employee
    {
        // TODO: Füge hier benötigte Properties und Konstruktoren ein.
    }

}