﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public class Article 
    {
        // TODO: Füge hier benötigte Properties und Konstruktoren ein.
    }

}