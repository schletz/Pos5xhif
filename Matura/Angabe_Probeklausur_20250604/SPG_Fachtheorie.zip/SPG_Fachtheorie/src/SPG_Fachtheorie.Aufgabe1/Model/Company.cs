﻿namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public class Company
    {
        // TODO: Füge hier benötigte Properties und Konstruktoren ein.
    }

}