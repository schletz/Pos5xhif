namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public class UserPremium
    {

    }
}
