﻿namespace SPG_Fachtheorie.Aufgabe2.Services
{
    public class PodcastService
    {
        public bool CalcTotalCosts(int customerId, DateTime begin, DateTime end)
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }

        public int CalcQuantityAdditionalAds(int playlistId)
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }

        public bool AddPostionForAd(int itemId, int position)
        {
            throw new NotImplementedException("Noch keine Implementierung vorhanden");
        }
    }
}
