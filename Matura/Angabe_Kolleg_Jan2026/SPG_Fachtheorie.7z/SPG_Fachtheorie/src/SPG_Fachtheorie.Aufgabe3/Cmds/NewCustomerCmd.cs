﻿namespace SPG_Fachtheorie.Aufgabe3.Cmds;

public record NewCustomerCmd(string FirstName, string LastName, string Email, string Phone);
