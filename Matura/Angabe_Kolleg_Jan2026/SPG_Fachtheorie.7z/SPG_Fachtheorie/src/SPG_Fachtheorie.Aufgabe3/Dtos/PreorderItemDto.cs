﻿namespace SPG_Fachtheorie.Aufgabe3.Dtos;

public record PreorderItemDto(string ProductName, int Quantity, decimal UnitPrice);
