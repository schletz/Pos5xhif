﻿namespace SPG_Fachtheorie.Aufgabe3.Dtos;

public record CustomerDto(int Id, string FirstName, string LastName, string Email, string Phone);
