﻿using System;

namespace SPG_Fachtheorie.Aufgabe1.Model;

public class DeliveryAttempt
{
    // TODO: Add your implementation
}