﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Driver
{
    // TODO: Add your implementation
}
