﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Depot
{
    // TODO: Add your implementation
}
