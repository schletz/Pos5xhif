﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public enum DeliveryStatus
{
    // TODO: Add your implementation
}
