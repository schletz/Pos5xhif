﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Shipment
{
    // TODO: Add your implementation
}
