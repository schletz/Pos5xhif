# Persönliche Angaben

Fügen Sie statt xxx Ihre Daten ein.
Ändern Sie sonst nichts an dieser Datei, da sie automatisiert ausgelesen wird.
Falls Sie diese Datei nicht ausfüllen, kann Ihre Arbeit nicht bewertet werden.

Klasse:  xxx
Vorname: xxx
Zuname:  xxx
Accountname (Ihr Schulaccount): xxx
