﻿using System;

namespace SPG_Fachtheorie.Aufgabe2.Services;

[Serializable]
public class DeliveryServiceException : Exception
{
    public DeliveryServiceException()
    {
    }

    public DeliveryServiceException(string? message) : base(message)
    {
    }

    public DeliveryServiceException(string? message, Exception? innerException) : base(message, innerException)
    {
    }
}