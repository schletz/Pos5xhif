﻿using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SPG_Fachtheorie.Aufgabe2.Services;

public class DeliveryService
{
    public record CustomerDto(int CustomerId, string Email, string PhoneNumber);
    public record OrderSummaryDto(int OrderId, int RestaurantId, string RestaurantName, DateTime OrderDate, DateTime? DeliveredAt);
    public record ProductSalesDto(int ProductId, string ProductName, decimal Revenue);
    public record DriverDeliveryCountDto(int DriverId, string Firstname, string Lastname, int DeliveryCount);

    private readonly DeliveryContext _db;

    public DeliveryService(DeliveryContext db)
    {
        _db = db;
    }

    /// <summary>
    /// Liefere eine Liste aller Kunden (Einträge in Customers)
    /// </summary>
    public List<CustomerDto> GetAllCustomers()
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }

    /// <summary>
    /// Liefere alle Orders eines bestimmten Kunden.
    /// </summary>
    public List<OrderSummaryDto> GetOrdersByCustomer(int customerId)
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }

    /// <summary>
    /// Liefere alle Produkte und deren Umsatz.
    /// Der Umsatz ist die Summe aus Product.Price x OrderItem.Quantity.
    /// Produkte ohne Umsatz (also die, die nie bestellt wurden) sollen
    /// auch mit 0.0 (decimal Wert) gelistet werden.
    /// </summary>
    public List<ProductSalesDto> GetProductsWithRevenue()
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }


    /// <summary>
    /// Liefere eine Liste aller Fahrer (Drivers) mit der Anzahl der Bestellungen,
    /// die sie geliefert haben. Die Anzahl der Bestellungen ist die Anzahl der Datensätze
    /// in Orders für den jeweiligen Fahrer.
    /// </summary>
    /// <returns></returns>
    public List<DriverDeliveryCountDto> GetDriverDeliveryCounts()
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }

    /// <summary>
    /// Erstellt eine Bestellung mit einem (1) OrderItem für ein bestimmtes Produkt.
    /// </summary>
    public Order PlaceOrder(int customerId, int restaurantId, Product product, int quantity)
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }


    public void MarkOrderAsDelivered(int orderId)
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }
}
