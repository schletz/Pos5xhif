using System;

namespace SPG_Fachtheorie.Aufgabe1.Model;
public class Item
{
    // TODO: Add your code

}