namespace SPG_Fachtheorie.Aufgabe1.Model;
public class WatchlistEntry
{
    // TODO: Add your code
}