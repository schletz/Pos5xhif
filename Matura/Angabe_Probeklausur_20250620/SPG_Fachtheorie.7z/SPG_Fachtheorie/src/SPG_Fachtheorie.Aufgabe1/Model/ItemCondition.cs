namespace SPG_Fachtheorie.Aufgabe1.Model;
public enum ItemCondition
{
    // TODO: Add your code
}