﻿using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe1.Model;
using System.Linq;

namespace SPG_Fachtheorie.Aufgabe1.Infrastructure;

public class MarketplaceContext : DbContext
{
    public MarketplaceContext(DbContextOptions options)
        : base(options)
    { }

    // TODO: Add your DbSets

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // TODO: Add your configuration

        // Tabellen-Namensschema anwenden (kleingeschriebene Klassennamen)
        // Muss die letzte Anweisung in OnModelCreating sein.
        // Sonst laufen die vordefinierten MasterTests nicht durch.
        ApplyNamingConventions(modelBuilder);
    }

    private void ApplyNamingConventions(ModelBuilder modelBuilder)
    {
        foreach (var entityType in modelBuilder.Model.GetEntityTypes().Where(t => !t.IsOwned()))
        {
            var clrName = entityType.ClrType.Name;
            entityType.SetTableName(clrName);
        }
    }
}
