#pragma warning disable CS8618
using System;
using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe2.Model;
    public class Product
{
    protected Product() { }
    public Product(string name, decimal price, Restaurant restaurant)
    {
        Name = name;
        Price = price;
        Restaurant = restaurant;
    }

    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }

    public Restaurant Restaurant { get; set; }
    public List<OrderItem> OrderItems { get; } = new();
}