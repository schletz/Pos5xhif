#pragma warning disable CS8618
using System;
using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe2.Model;
    public class OrderItem
{
    protected OrderItem() { }

    public OrderItem(Order order, Product product, int quantity)
    {
        Order = order;
        Product = product;
        Quantity = quantity;
    }

    public int Id { get; set; }
    public Order Order { get; set; }
    public Product Product { get; set; }
    public int Quantity { get; set; }
}