#pragma warning disable CS8618
using System;
using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe2.Model;
    public class Restaurant
{
    public Restaurant(string name, string address)
    {
        Name = name;
        Address = address;
    }

    public int Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }

    public List<Product> Products { get; } = new();
    public List<Order> Orders { get; } = new();
}