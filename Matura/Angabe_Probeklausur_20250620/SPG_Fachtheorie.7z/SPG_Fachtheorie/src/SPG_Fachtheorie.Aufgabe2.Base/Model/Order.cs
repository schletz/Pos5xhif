#pragma warning disable CS8618
using System;
using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe2.Model;
    public class Order
{
    protected Order() { }

    public Order(Customer customer, Restaurant restaurant, DateTime orderDate)
    {
        Customer = customer;
        Restaurant = restaurant;
        OrderDate = orderDate;
    }

    public int Id { get; set; }
    public Customer Customer { get; set; }
    public Restaurant Restaurant { get; set; }
    public Driver? Driver { get; set; }
    public DateTime OrderDate { get; set; }
    public DateTime? DeliveredAt { get; set; }

    public List<OrderItem> OrderItems { get; } = new();
}