#pragma warning disable CS8618
using System;
using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe2.Model;
    public class Customer
{

    public Customer(string phoneNumber, string email)
    {
        PhoneNumber = phoneNumber;
        Email = email;
    }

    public int Id { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }

    public List<Order> Orders { get; } = new();
}