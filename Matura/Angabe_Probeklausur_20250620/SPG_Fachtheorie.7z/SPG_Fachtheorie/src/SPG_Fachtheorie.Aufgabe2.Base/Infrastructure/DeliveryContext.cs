﻿using Bogus;
using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe2.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SPG_Fachtheorie.Aufgabe2.Infrastructure;

public class DeliveryContext : DbContext
{
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Restaurant> Restaurants => Set<Restaurant>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Driver> Drivers => Set<Driver>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    public DeliveryContext(DbContextOptions options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            var clrName = entityType.ClrType.Name;
            var tableName = char.ToLowerInvariant(clrName[0]) + clrName[1..];
            entityType.SetTableName(tableName);

            foreach (var property in entityType.GetProperties())
            {
                var propName = property.Name;
                property.SetColumnName(char.ToLowerInvariant(propName[0]) + propName[1..]);

                if (property.ClrType == typeof(string) && property.GetMaxLength() is null)
                    property.SetMaxLength(255);

                if (property.ClrType == typeof(DateTime)) property.SetPrecision(3);
                if (property.ClrType == typeof(DateTime?)) property.SetPrecision(3);
            }

            foreach (var fk in entityType.GetForeignKeys())
                fk.DeleteBehavior = DeleteBehavior.Restrict;
        }
    }

    public void Seed()
    {
        Randomizer.Seed = new Random(1234);
        var faker = new Faker("de");

        DateTime TruncateToSeconds(DateTime dt) =>
            new DateTime(dt.Ticks - (dt.Ticks % TimeSpan.TicksPerSecond), dt.Kind);

        // Restaurants + Produkte
        var restaurantFaker = new Faker<Restaurant>("de")
            .CustomInstantiator(f => new Restaurant(
                f.Company.CompanyName(),
                f.Address.FullAddress()
            ));

        var productFaker = new Faker<Product>("de");

        var restaurants = restaurantFaker.Generate(3);
        var products = restaurants
            .SelectMany(r =>
                productFaker
                    .CustomInstantiator(f => new Product(
                        f.Commerce.ProductName(),
                        Math.Round(f.Random.Decimal(5, 25), 1),
                        r
                    ))
                    .Generate(5)
            )
            .ToList();

        Restaurants.AddRange(restaurants);
        Products.AddRange(products);
        SaveChanges();

        // Kunden
        var customers = new Faker<Customer>("de")
            .CustomInstantiator(f => new Customer(
                f.Phone.PhoneNumber(),
                f.Internet.Email()
            ))
            .Generate(5);

        Customers.AddRange(customers);
        SaveChanges();

        // Fahrer
        var drivers = new Faker<Driver>("de")
            .CustomInstantiator(f => new Driver(
                f.Name.FirstName(),
                f.Name.LastName()
            ))
            .Generate(3);

        Drivers.AddRange(drivers);
        SaveChanges();

        // Bestellungen + OrderItems
        var orders = new List<Order>();
        var orderItems = new List<OrderItem>();

        var orderFaker = new Faker<Order>("de")
            .CustomInstantiator(f =>
            {
                var customer = f.PickRandom(customers);
                var restaurant = f.PickRandom(restaurants);
                var driver = f.PickRandom(drivers).OrNull(f, 0.5f);

                var orderDate = TruncateToSeconds(f.Date.Between(
                    new DateTime(2025, 1, 1),
                    new DateTime(2025, 6, 30)));

                var deliveredAt = driver is null
                ? null
                : TruncateToSeconds(orderDate.AddMinutes(f.Random.Int(20, 60))).OrNull(f, 0.5f);
                  

                var order = new Order(customer, restaurant, orderDate)
                {
                    DeliveredAt = deliveredAt,
                    Driver = driver
                };

                var restaurantProducts = products.Where(p => p.Restaurant == restaurant).ToList();
                var selectedProducts = f.Random.ListItems(restaurantProducts, f.Random.Int(1, 4));

                foreach (var product in selectedProducts)
                {
                    orderItems.Add(new OrderItem(order, product, f.Random.Int(1, 3)));
                }

                orders.Add(order);
                return order;
            });

        orderFaker.Generate(10);

        Orders.AddRange(orders);
        OrderItems.AddRange(orderItems);
        SaveChanges();
    }
}
