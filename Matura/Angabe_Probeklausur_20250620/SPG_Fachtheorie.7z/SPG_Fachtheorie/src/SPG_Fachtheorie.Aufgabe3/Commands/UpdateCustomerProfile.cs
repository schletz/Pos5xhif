﻿using System.ComponentModel.DataAnnotations;

namespace SPG_Fachtheorie.Aufgabe3.Commands;

// TODO: Add properties and validations.
public record UpdateCustomerProfile();
