﻿#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe3.Commands;
using SPG_Fachtheorie.Aufgabe3.Dtos;

namespace SPG_Fachtheorie.Aufgabe3.Controllers;
[Route("[controller]")]
[ApiController]
public class CustomersController : ControllerBase
{
    private readonly DeliveryContext _db;

    public CustomersController(DeliveryContext db)
    {
        _db = db;
    }

    /// <summary>
    /// GET /customers
    /// TODO: Add method parameters and logic.
    /// </summary>
    [HttpGet]
    [ProducesResponseType<List<CustomerDto>>(StatusCodes.Status200OK)]
    public async Task<ActionResult<List<CustomerDto>>> GetCustomers()
    {
        throw new NotImplementedException();
    }

    /// <summary>
    /// GET /customers/{id}/orders
    /// TODO: Add method parameters and logic.
    /// </summary>
    [HttpGet("{id}/orders")]
    [ProducesResponseType<CustomerWithOrdersDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<CustomerWithOrdersDto>> GetCustomerWithOrders()
    {
        throw new NotImplementedException();
    }


    /// <summary>
    /// PATCH /customers/{id}
    /// TODO: Add method parameters and logic.
    /// </summary>
    [HttpPatch("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateProfile()
    {
        throw new NotImplementedException();
    }
}
