﻿namespace SPG_Fachtheorie.Aufgabe3.Dtos;

public record CustomerDto(int Id, string PhoneNumber, string Email);
public record CustomerWithOrdersDto(int Id, string Email, List<OrderDto> Orders);
public record OrderDto(int Id, int RestaurantId, string RestaurantName, DateTime OrderDate, DateTime? DeliveredAt);
