﻿// *************************************************************************************************
// VORDEFINIERTE INTEGRATION TESTS ZUR AUTOMATISIERTEN KONTROLLE
// Hier ist nichts auszufüllen oder zu bearbeiten!
// Sie können die Tests zur Kontrolle ausführen, aber hier wird nichts implementiert.
// Bei der Kontrolle der Abgaben wird diese Datei durch die Originalversion ersetzt.
// *************************************************************************************************
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe3.Test;

[Collection("Sequential")]
public class Aufgabe3MasterTests : IClassFixture<TestWebApplicationFactory>
{
    private readonly TestWebApplicationFactory _factory;

    public Aufgabe3MasterTests(TestWebApplicationFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task T01_GetCustomersStatusOkTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/customers");
        Assert.True(status == HttpStatusCode.OK, $"Wrong status code for GET /customers.");
    }

    [Fact]
    public async Task T02_GetCustomersOkWithDataTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/customers");
        var expected = @"[{""id"":1,""phoneNumber"":""(0818) 549603751"",""email"":""Thalea62@gmail.com""},{""id"":2,""phoneNumber"":""+49-873-2641889"",""email"":""Bilal98@hotmail.com""},{""id"":3,""phoneNumber"":""+49-2325-30053148"",""email"":""Collien_Isekenmeier@yahoo.com""},{""id"":4,""phoneNumber"":""+49-747-6533606"",""email"":""Marcus.Kolokas@gmail.com""},{""id"":5,""phoneNumber"":""(0758) 027678403"",""email"":""Luke.Mesloh@yahoo.com""}]";
        Assert.True(JsonElement.DeepEquals(data, JsonDocument.Parse(expected).RootElement));
    }

    [Fact]
    public async Task T03_GetCustomerWithOrdersStatusNotFoundTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/customers/999/orders");
        Assert.True(status == HttpStatusCode.NotFound, $"Wrong status code for GET /customers/999/orders.");
    }

    [Fact]
    public async Task T04_GetCustomerWithOrdersStatusOkTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/customers/3/orders");
        Assert.True(status == HttpStatusCode.OK, $"Wrong status code for GET /customers/999/orders.");
    }

    [Fact]
    public async Task T04_GetCustomerWithOrdersDataWithoutFilterTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/customers/3/orders");
        var expected = @"{""id"":3,""email"":""Collien_Isekenmeier@yahoo.com"",""orders"":[{""id"":8,""restaurantId"":2,""restaurantName"":""Saflanis - Rahn"",""orderDate"":""2025-06-19T18:14:03"",""deliveredAt"":null}]}";
        Assert.True(JsonElement.DeepEquals(data, JsonDocument.Parse(expected).RootElement));
    }

    [Fact]
    public async Task T04_GetCustomerWithOrdersDataWithFilterFalseTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/customers/3/orders?includeDelivered=false");
        var expected = @"{""id"":3,""email"":""Collien_Isekenmeier@yahoo.com"",""orders"":[{""id"":8,""restaurantId"":2,""restaurantName"":""Saflanis - Rahn"",""orderDate"":""2025-06-19T18:14:03"",""deliveredAt"":null}]}";
        Assert.True(JsonElement.DeepEquals(data, JsonDocument.Parse(expected).RootElement));
    }

    [Fact]
    public async Task T04_GetCustomerWithOrdersDataWithFilterTrueTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/customers/3/orders?includeDelivered=true");
        var expected = @"{""id"":3,""email"":""Collien_Isekenmeier@yahoo.com"",""orders"":[{""id"":5,""restaurantId"":1,""restaurantName"":""Thomas - Hengmith"",""orderDate"":""2025-01-23T01:52:49"",""deliveredAt"":""2025-01-23T02:45:49""},{""id"":6,""restaurantId"":1,""restaurantName"":""Thomas - Hengmith"",""orderDate"":""2025-01-06T17:35:24"",""deliveredAt"":""2025-01-06T18:03:24""},{""id"":8,""restaurantId"":2,""restaurantName"":""Saflanis - Rahn"",""orderDate"":""2025-06-19T18:14:03"",""deliveredAt"":null}]}";
        Assert.True(JsonElement.DeepEquals(data, JsonDocument.Parse(expected).RootElement));
    }

    [Fact]
    public async Task T05_UpdateProfileStatusNotFoundTest()
    {
        _factory.SeedDatabase();
        var (status, _) = await _factory.PatchHttpContent("/customers/999", new {PhoneNumber = "+43 123", Email = "a@b.at"});
        Assert.True(status == HttpStatusCode.NotFound, $"Wrong status code for PATCH /customers/999.");
    }

    [Theory]
    [InlineData("", "a@b.at")]
    [InlineData("+43 123", "")]
    public async Task T06_UpdateProfileStatusBadRequestOnInvalidDataTest(string phoneNumber, string email)
    {
        _factory.SeedDatabase();
        var (status, _) = await _factory.PatchHttpContent("/customers/3", new { PhoneNumber = phoneNumber, Email = email });
        Assert.True(status == HttpStatusCode.BadRequest, $"Wrong status code for PATCH /customers/3 with invalid data.");
    }

    [Fact]
    public async Task T07_UpdateProfileStatusNoContentTest()
    {
        _factory.SeedDatabase();
        var (status, _) = await _factory.PatchHttpContent("/customers/3", new { PhoneNumber = "+43 123", Email = "a@b.at" });
        Assert.True(status == HttpStatusCode.NoContent, $"Wrong status code for PATCH /customers/3 with valid data.");
    }

    [Fact]
    public async Task T08_UpdateProfileStatusDatabaseOkTest()
    {
        _factory.SeedDatabase();
        await _factory.PatchHttpContent("/customers/3", new { PhoneNumber = "+43 123", Email = "a@b.at" });
        var row = _factory.QueryDatabase(db => db.Customers.First(c => c.Id == 3));
        Assert.True(row.PhoneNumber == "+43 123" && row.Email == "a@b.at", "Customer data not updated in database.");
    }

}
