﻿// *************************************************************************************************
// VORDEFINIERTE INTEGRATION TESTS ZUR AUTOMATISIERTEN KONTROLLE
// Hier ist nichts auszufüllen oder zu bearbeiten!
// Sie können die Tests zur Kontrolle ausführen, aber hier wird nichts implementiert.
// Bei der Kontrolle der Abgaben wird diese Datei durch die Originalversion ersetzt.
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe1.Infrastructure;
using System;
using System.Diagnostics;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe1.Test;

/// <summary>
/// Integrationstests zur Kontrolle der Datenbankschema-Generierung und Constraints.
/// </summary>
public class Aufgabe1MasterTests
{
    [Fact]
    public void T00_CanCreateDatabaseTest()
    {
        using var db = GetEmptyDbContext();
        string createScript = db.Database.GenerateCreateScript();
        Debug.Write(createScript);

        using var command = db.Database.GetDbConnection().CreateCommand();
        command.CommandText = $"SELECT COUNT(*) FROM sqlite_master WHERE type='table';";
        db.Database.OpenConnection();
        var result = (long?)command.ExecuteScalar();
        Assert.True(result >= 3, $"Less than 3 Tables found. Check your DbSets.");
    }

    [Fact]
    public void T01_InsertUserTest() => InsertRow(
        "INSERT INTO User (Username, Name_Firstname, Name_Lastname, Email) VALUES ('testuser', 'Max', 'Mustermann', 'max@test.at')");

    [Fact]
    public void T02_UserNameIsKeyTest() => EnsureConstraint("User", "Username", "TEXT", true);

    [Fact]
    public void T03_InsertCategoryTest() => InsertRow(
        "INSERT INTO Category (Name) VALUES ('Elektronik')");

    [Fact]
    public void T04_CategoryNameIsUniqueTest()
    {
        // Zuerst testen, ob überhaupt ein INSERT möglich ist.
        // Sonst läuft der Test durch, wenn ein anderer Fehler (keine Table) geliefert wird.
        InsertRow("INSERT INTO Category (Name) VALUES ('Haushalt')");
        InsertRowShouldFail(
            "INSERT INTO Category (Name) VALUES ('Haushalt')",
            "INSERT INTO Category (Name) VALUES ('Haushalt')");
    }

    [Fact]
    public void T05_InsertItemTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO Item (Title, Description, Price, Condition, SellerUsername, CategoryId, CreatedAt, SoldAt) VALUES ('Java Buch', 'Sehr gut erhalten', 12.90, 'Used', 'seller1', 1, '2025-06-01T10:00:00', NULL)");

    [Fact]
    public void T06_ItemConditionEnumIsStringTest() => EnsureConstraint("Item", "Condition", "TEXT");

    [Fact]
    public void T07_InsertMessageTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO Message (Content, SentAt, AuthorUsername, ItemId) VALUES ('Ist das noch verfügbar?', '2025-06-01T12:00:00', 'buyer1', 1)");

    [Fact]
    public void T08_InsertWatchlistEntryTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO WatchlistEntry (Username, ItemId) VALUES ('buyer1', 1)");

    private MarketplaceContext GetEmptyDbContext()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new MarketplaceContext(options);
        db.Database.EnsureCreated();
        return db;
    }

    private void InsertRowShouldFail(params string[] commandsTexts) => InsertRow(true, true, commandsTexts);
    private void InsertRow(params string[] commandsTexts) => InsertRow(false, true, commandsTexts);
    private void InsertRow(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(false, foreignKeyCheck, commandsTexts);
    private void InsertRow(bool shouldFail, bool foreignKeyCheck, params string[] commandsTexts)
    {
        using var db = GetEmptyDbContext();
        bool failed = false;
        using (var command = db.Database.GetDbConnection().CreateCommand())
        {
            command.CommandText = $"PRAGMA foreign_keys = {(foreignKeyCheck ? 1 : 0)}";
            db.Database.OpenConnection();
            command.ExecuteNonQuery();
        }

        foreach (var commandText in commandsTexts)
        {
            using var command = db.Database.GetDbConnection().CreateCommand();
            command.CommandText = commandText;
            db.Database.OpenConnection();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (SqliteException e)
            {
                failed = true;
                if (!shouldFail)
                    Assert.Fail($"Query failed: {commandText} with error {e.InnerException?.Message ?? e.Message}");
            }
        }
        if (shouldFail && !failed)
            Assert.Fail($"Query should fail, but it didn't. {string.Join(Environment.NewLine, commandsTexts)}");
    }

    private void EnsureConstraint(string table, string column, string type, bool isPk = false)
    {
        using var db = GetEmptyDbContext();
        using var cmd = db.Database.GetDbConnection().CreateCommand();
        cmd.CommandText = $"PRAGMA table_info({table})";
        db.Database.OpenConnection();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            string columnName = reader.GetString(1);
            string columnType = reader.GetString(2);
            bool columnPk = reader.GetBoolean(5);
            if (columnName.Equals(column, StringComparison.OrdinalIgnoreCase))
            {
                Assert.True(columnType == type, $"Wrong datatype for {table}.{column}. Expected: {type}, given: {columnType}.");
                Assert.True(columnPk == isPk, $"Wrong primary key constraint {table}.{column}. Expected: {isPk}, given: {columnPk}.");
                return;
            }
        }
        Assert.Fail($"Column {table}.{column} not found.");
    }
}
