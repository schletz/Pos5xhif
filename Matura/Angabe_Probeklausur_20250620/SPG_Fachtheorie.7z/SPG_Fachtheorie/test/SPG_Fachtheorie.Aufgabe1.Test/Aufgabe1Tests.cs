// *************************************************************************************************
// UNITTESTS F�R AUFGABE 1
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe1.Infrastructure;
using SPG_Fachtheorie.Aufgabe1.Model;
using System;
using System.Linq;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe1.Test;

public class Aufgabe1Tests
{
    [Fact]
    public void CreateDatabaseTest()
    {
        using var db = GetEmptyDbContext();
    }

    /// <summary>
    /// Pr�ft, ob Enum ItemCondition als string gespeichert wird.
    /// </summary>
    [Fact]
    public void PersistEnumInItemTest()
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }


    /// <summary>
    /// Pr�ft, ob das ValueObject Name korrekt gespeichert und gelesen werden kann.
    /// </summary>
    [Fact]
    public void PersistValueObjectInUserTest()
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }

    /// <summary>
    /// Pr�ft, ob Category.Name als unique gespeichert ist.
    /// </summary>
    [Fact]
    public void EnsureNameInCategoryIsUniqueTest()
    {
        // TODO: Add your code
        throw new NotImplementedException();
    }


    private MarketplaceContext GetEmptyDbContext()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new MarketplaceContext(options);
        db.Database.EnsureCreated();
        return db;
    }
}
