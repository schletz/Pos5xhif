// ************************************************************************************************
// VORDEFINIERTE INTEGRATION TESTS ZUR AUTOMATISIERTEN KONTROLLE
// Hier ist nichts auszuf�llen oder zu bearbeiten!
// Sie k�nnen die Tests zur Kontrolle ausf�hren, aber hier wird nichts implementiert.
// Bei der Kontrolle der Abgaben wird diese Datei durch die Originalversion ersetzt.
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text.Json;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe2.Test;

public class Aufgabe2MasterTests
{
    [Fact]
    public void T00_CreateSeededDatabaseForServiceSuccessTest()
    {
        using var db = GetSeededDbContext();
        Assert.True(db.Customers.Count() > 0);
    }

    [Fact]
    public void T01_GetAllCustomers_ReturnsCorrectRows()
    {
        using var db = GetSeededDbContext();
        var service = new DeliveryService(db);

        var sql = "SELECT id, email, phoneNumber FROM customer";
        var rows = QueryDatabase(db.Database, sql,
            r => new { CustomerId = r.GetInt32(0), Email = r.GetString(1), PhoneNumber = r.GetString(2) });

        var result = service.GetAllCustomers();
        Assert.True(rows.Count == result.Count,
            $"GetAllCustomers row count failed: expected {rows.Count}, got {result.Count}.");

        foreach (var row in rows)
            Assert.True(result.Any(x => JsonSerializer.Serialize(x) == JsonSerializer.Serialize(row)),
                $"GetAllCustomers: row not found in your result: {JsonSerializer.Serialize(row)}.");
    }

    [Fact]
    public void T02_GetOrdersByCustomer_ReturnsCorrectRows()
    {
        using var db = GetSeededDbContext();
        var service = new DeliveryService(db);
        var customerIds = db.Customers.Select(c => c.Id).ToList();

        foreach(var customerId in customerIds)
        {
            var sql = $@"
            SELECT o.id, r.id, r.name, o.orderDate, o.deliveredAt
            FROM [order] o INNER JOIN restaurant r ON (o.restaurantId = r.id)
            WHERE o.customerId = {customerId}";

            var rows = QueryDatabase(db.Database, sql,
                r => new
                {
                    OrderId = r.GetInt32(0),
                    RestaurantId = r.GetInt32(1),
                    RestaurantName = r.GetString(2),
                    OrderDate = r.GetDateTime(3),
                    DeliveredAt = r.IsDBNull(4) ? (DateTime?)null : r.GetDateTime(4)
                });

            var result = service.GetOrdersByCustomer(customerId);
            Assert.True(rows.Count == result.Count,
                $"GetOrdersByCustomer for Customer {customerId} row count failed: expected {rows.Count}, got {result.Count}.");

            foreach (var row in rows)
                Assert.True(result.Any(x => JsonSerializer.Serialize(x) == JsonSerializer.Serialize(row)),
                    $"GetOrdersByCustomer: row not found in your result for Customer {customerId}: {JsonSerializer.Serialize(row)}.");

        }
    }

    [Fact]
    public void T03_GetProductsWithRevenue_ReturnsCorrectRows()
    {
        using var db = GetSeededDbContext();
        var service = new DeliveryService(db);

        var sql = @"
            SELECT p.id, p.name, IFNULL(SUM(p.price * oi.quantity), 0.0)
            FROM product p LEFT JOIN orderItem oi ON (oi.productId = p.id)
            GROUP BY p.id, p.name";

        var rows = QueryDatabase(db.Database, sql,
            r => new { ProductId = r.GetInt32(0), ProductName = r.GetString(1), Revenue = r.GetDecimal(2) });

        var result = service.GetProductsWithRevenue();
        Assert.True(rows.Count == result.Count,
            $"GetProductsWithRevenue row count failed: expected {rows.Count}, got {result.Count}.");

        foreach (var row in rows)
            Assert.True(result.Any(x => JsonSerializer.Serialize(x) == JsonSerializer.Serialize(row)),
                $"GetProductsWithRevenue: Row not found in your result: {JsonSerializer.Serialize(row)}.");
    }

    [Fact]
    public void T04_GetDriverDeliveryCounts_ReturnsCorrectRows()
    {
        using var db = GetSeededDbContext();
        var service = new DeliveryService(db);

        var sql = @"
            SELECT d.id, d.firstName, d.lastName, COUNT(o.id)
            FROM driver d LEFT JOIN [order] o ON (o.driverId = d.id)
            GROUP BY d.id, d.firstName, d.lastName";

        var rows = QueryDatabase(db.Database, sql,
            r => new
            {
                DriverId = r.GetInt32(0),
                Firstname = r.GetString(1),
                Lastname = r.GetString(2),
                DeliveryCount = r.GetInt32(3)
            });

        var result = service.GetDriverDeliveryCounts();
        Assert.True(rows.Count == result.Count,
            $"GetDriverDeliveryCounts row count failed: expected {rows.Count}, got {result.Count}.");

        foreach (var row in rows)
            Assert.True(result.Any(x => JsonSerializer.Serialize(x) == JsonSerializer.Serialize(row)),
                $"Test failed. Row not found in your result: {JsonSerializer.Serialize(row)}.");
    }


    [Theory]
    [InlineData(3, 1, 2, -1, "Quantity must be positive.")]
    [InlineData(999, 1, 2, 1, "Customer not found.")]
    [InlineData(1, 999, 2, 1, "Restaurant not found.")]
    [InlineData(1, 3, 6, 1, "Restaurant does not offer this product.")]
    [InlineData(1, 2, 6, 1, "")]

    public void T05_PlaceOrderTest(
        int customerId, int restaurantId, int productId, int quantity, string errorMessage)
    {
        using var db = GetSeededDbContext();
        var service = new DeliveryService(db);
        var product = db.Products.First(p => p.Id == productId);
        if (string.IsNullOrEmpty(errorMessage))
        {
            var order = service.PlaceOrder(customerId, restaurantId, product, quantity);
            var rows = QueryDatabase(db.Database, $"select id from [order] where customerId = {customerId} and restaurantId = {restaurantId}",
                reader => new { Id = reader.GetInt32(0) });
            Assert.True(rows.Any() && rows.Single().Id != 0, $"Missing order after calling PlaceOrder() in database.");
            Assert.True(rows.Single().Id == order.Id, $"Wrong entity returned from PlaceOrder().");

            var rows2 = QueryDatabase(db.Database, $"select id, productId from orderitem where orderId = {rows.Single().Id}",
                reader => new { Id = reader.GetInt32(0), ProductId = reader.GetInt32(1) });
            Assert.True(rows2.Any() && rows2.Single().Id != 0, $"Missing orderitem after calling PlaceOrder() in database.");
            Assert.True(rows2.Single().ProductId == productId, $"Wrong product in orderitem after call PlaceOrder() in database.");
            return;
        }
        var ex = Assert.Throws<DeliveryServiceException>(() => service.PlaceOrder(customerId, restaurantId, product, quantity));
        Assert.True(ex.Message == errorMessage, $"Wrong Exception message {ex.Message}, expected: {errorMessage}");
    }


    [Theory]
    [InlineData(999, "Order not found.")]
    [InlineData(4, "Order already delivered.")]
    [InlineData(1, "")]

    public void T06_MarkOrderAsDeliveredTest(
        int orderId, string errorMessage)
    {
        using var db = GetSeededDbContext();
        var service = new DeliveryService(db);
        if (string.IsNullOrEmpty(errorMessage))
        {
            service.MarkOrderAsDelivered(orderId);
            var rows = QueryDatabase(db.Database, $"select deliveredAt from [order] where id = {orderId}",
                reader => new { DeliveredAt = reader.IsDBNull(0) ? (DateTime?) null : reader.GetDateTime(0) });
            Assert.True(rows.Single().DeliveredAt.HasValue, $"No value for deliveredAt in database.");
            return;
        }
        var ex = Assert.Throws<DeliveryServiceException>(() => service.MarkOrderAsDelivered(orderId));
        Assert.True(ex.Message == errorMessage, $"Wrong Exception message {ex.Message}, expected: {errorMessage}");
    }

    private DeliveryContext GetSeededDbContext()
    {
        //var options = new DbContextOptionsBuilder()
        //    .UseSqlite("DataSource=delivery.db")
        //    .Options;

        //var db = new DeliveryContext(options);
        //db.Database.EnsureDeleted();
        //db.Database.EnsureCreated();
        //db.Seed();
        //return db;

        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new DeliveryContext(options);
        db.Database.EnsureCreated();
        db.Seed();
        return db;
    }

    private List<T> QueryDatabase<T>(DatabaseFacade database, string commandText, Func<DbDataReader, T> projection)
    {
        using var command = database.GetDbConnection().CreateCommand();
        command.CommandText = commandText;
        database.OpenConnection();
        using var reader = command.ExecuteReader();
        var rows = new List<T>();
        while (reader.Read())
            rows.Add(projection(reader));
        return rows;
    }
}
