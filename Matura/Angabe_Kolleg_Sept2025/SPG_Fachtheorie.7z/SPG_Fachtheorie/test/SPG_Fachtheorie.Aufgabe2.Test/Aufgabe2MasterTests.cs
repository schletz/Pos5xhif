// *************************************************************************************************
// VORDEFINIERTE INTEGRATION TESTS ZUR AUTOMATISIERTEN KONTROLLE
// Hier ist nichts auszuf�llen oder zu bearbeiten!
// Sie k�nnen die Tests zur Kontrolle ausf�hren, aber hier wird nichts implementiert.
// Bei der Kontrolle der Abgaben wird diese Datei durch die Originalversion ersetzt.
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Services;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text.Json;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe2.Test;

public class Aufgabe2MasterTests
{
    [Fact]
    public void T00_CreateSeededDatabaseForServiceSuccessTest()
    {
        using var db = GetSeededDbContext();
        Assert.True(db.Members.Count() > 0);
    }

    [Fact]
    public void T01_GetActiveMembersTest()
    {
        using var db = GetSeededDbContext();
        var service = new FitnessService(db);
        var sql = @"
                select m.id, m.firstName, m.lastName, m.email
                from member m
                where m.isActive = 1";
        var rows = QueryDatabase(db.Database, sql,
            reader => new { Id = reader.GetInt32(0), FirstName = reader.GetString(1), LastName = reader.GetString(2), Email = reader.GetString(3) });
        var members = service.GetActiveMembers();
        Assert.True(members.Count == rows.Count, $"GetActiveMembers row count failed: expected {rows.Count}, got {members.Count}.");
        foreach (var row in rows)
            Assert.True(members.Any(m => JsonSerializer.Serialize(m) == JsonSerializer.Serialize(row)),
                $"Test failed. Row not found in your result: {JsonSerializer.Serialize(row)}.");
    }

    [Fact]
    public void T02_GetTrainingSessionsWithParticipantCountsTest()
    {
        using var db = GetSeededDbContext();
        var service = new FitnessService(db);
        var sql = @"
                select ts.id, r.name, ts.time, t.firstName, t.lastName, COUNT(*) as count
                from trainingSession ts  inner join participation p on (p.trainingSessionId = ts.id)
                inner join room r on (ts.roomId = r.id )
                inner join trainer t on (ts.trainerId = t.id )
                group by ts.id, r.name, ts.time, t.firstName || ' ' || t.lastName;";
        var rows = QueryDatabase(db.Database, sql,
            reader => new
            {
                Id = reader.GetInt32(0),
                RoomName = reader.GetString(1),
                DateTime = reader.GetDateTime(2),
                TrainerFirstName = reader.GetString(3),
                TrainerLastName = reader.GetString(4),
                ParticipantCount = reader.GetInt32(5)
            });
        var sessions = service.GetTrainingSessionsWithParticipantCounts();
        Assert.True(sessions.Count == rows.Count, $"GetTrainingSessionsWithParticipantCounts row count failed: expected {rows.Count}, got {sessions.Count}.");
        foreach (var row in rows)
            Assert.True(sessions.Any(m => JsonSerializer.Serialize(m) == JsonSerializer.Serialize(row)),
                $"Test failed. Row not found in your result: {JsonSerializer.Serialize(row)}.");
    }


    [Fact]
    public void T03_GetMaxRatingCountPerTrainerTest()
    {
        using var db = GetSeededDbContext();
        var service = new FitnessService(db);
        var sql = @"
                select t.id, t.firstName, t.lastName,
	                (select count(*) from trainingSession ts inner join participation p on (p.trainingSessionId = ts.id)
	                where ts.trainerId = t.id and p.rating = 5) as maxRatingCount
                from trainer t";
        var rows = QueryDatabase(db.Database, sql,
            reader => new
            {
                Id = reader.GetInt32(0),
                FirstName = reader.GetString(1),
                LastName = reader.GetString(2),
                MaxRatingCount = reader.GetInt32(3)
            });
        var sessions = service.GetMaxRatingCountPerTrainer();
        Assert.True(sessions.Count == rows.Count, $"GetMaxRatingCountPerTrainer row count failed: expected {rows.Count}, got {sessions.Count}.");
        foreach (var row in rows)
            Assert.True(sessions.Any(m => JsonSerializer.Serialize(m) == JsonSerializer.Serialize(row)),
                $"Test failed. Row not found in your result: {JsonSerializer.Serialize(row)}.");
    }

    [Theory]
    [InlineData(999, 1, "Member not found.")]
    [InlineData(1, 999, "TrainingSession not found.")]
    [InlineData(1, 8, "Member already registered.")]
    [InlineData(1, 1, "Training Session is already full.")]
    [InlineData(2, 8, "")]
    public void T04_RegisterMemberToTrainingTest(int memberId, int trainingSessionId, string errorMessage)
    {
        using var db = GetSeededDbContext();
        var service = new FitnessService(db);
        if (string.IsNullOrEmpty(errorMessage))
        {
            service.RegisterMemberToTrainingSession(2, 8);
            var rows = QueryDatabase(db.Database, "select id from participation where memberId = 2 and trainingSessionId = 8",
                reader => new { Id = reader.GetInt32(0) });
            Assert.True(rows.Single().Id != 0, $"Missing participation for member 2 in training session 8 in database.");
            return;
        }
        var ex = Assert.Throws<FitnessServiceException>(() => service.RegisterMemberToTrainingSession(memberId, trainingSessionId));
        Assert.True(ex.Message == errorMessage, $"Wrong Exception message {ex.Message}");
    }

    [Theory]
    [InlineData(5, 1, 6, "Rating must be between 1 and 5.")]
    [InlineData(1, 1, 4, "Participation not found.")]
    [InlineData(5, 1, 3, "")]
    public void T05_UpdateRatingTest(int memberId, int trainingSessionId, int rating, string errorMessage)
    {
        using var db = GetSeededDbContext();
        var service = new FitnessService(db);
        if (string.IsNullOrEmpty(errorMessage))
        {
            service.UpdateRating(memberId, trainingSessionId, rating);
            var rows = QueryDatabase(db.Database, "select rating from participation where memberId = 5 and trainingSessionId = 1",
                reader => new { Rating = reader.GetInt32(0) });
            Assert.True(rows.Single().Rating == 3, $"Wrong rating in database.");
            return;
        }
        var ex = Assert.Throws<FitnessServiceException>(() => service.UpdateRating(memberId, trainingSessionId, rating));
        Assert.True(ex.Message == errorMessage, $"Wrong Exception message {ex.Message}");
    }
    private FitnessContext GetSeededDbContext()
    {
        //var options = new DbContextOptionsBuilder()
        //    .UseSqlite("DataSource=fitness.db")
        //    .Options;

        //var db = new FitnessContext(options);
        //db.Database.EnsureDeleted();
        //db.Database.EnsureCreated();
        //db.Seed();
        //return db;
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new FitnessContext(options);
        db.Database.EnsureCreated();
        db.Seed();
        return db;
    }

    private List<T> QueryDatabase<T>(DatabaseFacade database, string commandText, Func<DbDataReader, T> projection)
    {
        using var command = database.GetDbConnection().CreateCommand();
        command.CommandText = commandText;
        database.OpenConnection();
        using var reader = command.ExecuteReader();
        var rows = new List<T>();
        while (reader.Read())
            rows.Add(projection(reader));
        return rows;
    }
}