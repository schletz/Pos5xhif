﻿// *************************************************************************************************
// VORDEFINIERTE INTEGRATION TESTS ZUR AUTOMATISIERTEN KONTROLLE
// Hier ist nichts auszufüllen oder zu bearbeiten!
// Sie können die Tests zur Kontrolle ausführen, aber hier wird nichts implementiert.
// Bei der Kontrolle der Abgaben wird diese Datei durch die Originalversion ersetzt.
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe1.Infrastructure;
using System;
using System.Diagnostics;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe1.Test;

/// <summary>
/// Insert-Tests für das neue EF-Core Modell.
/// Diese Tests fügen direkt Daten per SQL ein und prüfen, ob die Tabellen korrekt funktionieren.
/// </summary>
public class Aufgabe1MasterTests
{
    /// <summary>
    /// Prüft, ob alle Tabellen in der Datenbank erstellt wurden.
    /// WICHTIG: Der Name der Tabelle wird vom Namen des DbSets im Context bestimmt, er muss wie die unteren Tabellen heißen!
    /// </summary>
    [Fact]
    public void T00_CanCreateDatabaseTest()
    {
        using var db = GetEmptyDbContext();
        string createScript = db.Database.GenerateCreateScript();
        Debug.Write(createScript);

        using var command = db.Database.GetDbConnection().CreateCommand();
        command.CommandText = $"SELECT COUNT(*) FROM sqlite_master WHERE type='table';";
        db.Database.OpenConnection();
        var result = (long?) command.ExecuteScalar();
        Assert.True(result >= 3, $"Less than 3 Tables found. Check your DbSets.");
    }

    [Fact]
    public void T01_InsertAllergenTest() => InsertRow(
        "INSERT INTO Allergen (Shortname, Name) VALUES ('E', 'Ei')");

    [Fact]
    public void T02_InsertAllergenShortnameUniqueTest() => InsertRowShouldFail(
        "INSERT INTO Allergen (Shortname, Name) VALUES ('E', 'Ei')",
        "INSERT INTO Allergen (Shortname, Name) VALUES ('E', 'Ei')");

    [Fact]
    public void T03_InsertSchoolTest() => InsertRow(
        "INSERT INTO School (Number, Name, Address_Street, Address_Zip, Address_City) VALUES (1, 'HTL', 'Straße', '1234', 'Stadt')");

    [Fact]
    public void T04_InsertSchoolNumberAsKeyTest() => EnsureConstraint("School", "Number", "INTEGER", isPk: true);

    [Fact]
    public void T05_InsertSchoolNameIsUniqueTest() => InsertRowShouldFail(
        "INSERT INTO School (Number, Name, Address_Street, Address_Zip, Address_City) VALUES (1, 'HTL', 'Straße', '1234', 'Stadt')",
        "INSERT INTO School (Number, Name, Address_Street, Address_Zip, Address_City) VALUES (2, 'HTL', 'Straße', '1234', 'Stadt')");

    [Fact]
    public void T06_InsertStudentTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO Student (FirstName, LastName, Email, SchoolNumber) VALUES ('Max', 'Muster', 'max@schule.at', 1)");

    [Fact]
    public void T07_InsertMealTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO Meal (Name, Price, Date, Type, SchoolNumber, Description) VALUES ('Schnitzel', 5.50, '2025-06-01T12:00:00', 'MeatDish', 1, 'Lecker')");

    [Fact]
    public void T08_MealTypeEnumIsStringTest() => EnsureConstraint("Meal", "Type", "TEXT");

    [Fact]
    public void T09_InsertMealAllergenTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO MealAllergen (MealId, AllergenId) VALUES (1, 1)");

    [Fact]
    public void T10_InsertMealOrderTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO MealOrder (OrderDate, Status, StudentId, MealId) VALUES ('2025-06-01T10:00:00', 'Ordered', 1, 1)");

    [Fact]
    public void T11_MealOrderEnumIsStringTest() => EnsureConstraint("MealOrder", "Status", "TEXT");



    private MealContext GetEmptyDbContext()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new MealContext(options);
        db.Database.EnsureCreated();
        return db;
    }

    private void InsertRowShouldFail(params string[] commandsTexts) => InsertRow(true, true, commandsTexts);
    private void InsertRow(params string[] commandsTexts) => InsertRow(false, true, commandsTexts);
    private void InsertRow(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(false, foreignKeyCheck, commandsTexts);
    private void InsertRow(bool shouldFail, bool foreignKeyCheck, params string[] commandsTexts)
    {
        using var db = GetEmptyDbContext();
        bool failed = false;
        using (var command = db.Database.GetDbConnection().CreateCommand())
        {
            command.CommandText = $"PRAGMA foreign_keys = {(foreignKeyCheck ? 1 : 0)}";
            db.Database.OpenConnection();
            command.ExecuteNonQuery();
        }

        foreach (var commandText in commandsTexts)
        {
            using var command = db.Database.GetDbConnection().CreateCommand();
            command.CommandText = commandText;
            db.Database.OpenConnection();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (SqliteException e)
            {
                failed = true;
                if (!shouldFail)
                    Assert.Fail($"Query failed: {commandText} with error {e.InnerException?.Message ?? e.Message}");
            }
        }
        if (shouldFail && !failed)
            Assert.Fail($"Query shoud fail, but it dosen't. {string.Join(Environment.NewLine, commandsTexts)}");
    }

    private void EnsureConstraint(string table, string column, string type, bool isPk = false)
    {
        using var db = GetEmptyDbContext();
        using var cmd = db.Database.GetDbConnection().CreateCommand();
        cmd.CommandText = $"PRAGMA table_info({table})";
        db.Database.OpenConnection();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            string columnName = reader.GetString(1); // Spaltenname
            string columnType = reader.GetString(2); // Spaltentyp
            bool columnPk = reader.GetBoolean(5); // PK Constraint
            if (columnName.Equals(column, StringComparison.OrdinalIgnoreCase))
            {
                Assert.True(columnType == type, $"Wrong datatype for {table}.{column}. Expected: {type}, given: {columnType}.");
                Assert.True(columnPk == isPk, $"Wrong primary key constraint {table}.{column}. Expected: {isPk}, given: {columnPk}.");
                return;
            }
        }
        Assert.Fail($"Column {table}.{column} not found.");
    }
}

