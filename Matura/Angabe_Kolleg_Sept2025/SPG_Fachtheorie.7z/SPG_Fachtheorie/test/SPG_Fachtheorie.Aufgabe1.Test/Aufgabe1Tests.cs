// *************************************************************************************************
// UNITTESTS F�R AUFGABE 1
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe1.Infrastructure;
using SPG_Fachtheorie.Aufgabe1.Model;
using System;
using System.Linq;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe1.Test;

public class Aufgabe1Tests
{
    /// <summary>
    /// Pr�ft, ob alle Tabellen in der Datenbank erstellt wurden.
    /// Dummytest als Vorlage.
    /// </summary>
    [Fact]
    public void CreateDatabaseTest()
    {
        using var db = GetEmptyDbContext();
    }

    /// <summary>
    /// _PersistEnumInMealTest_ beweist, dass die Enum _MealType_ in _Meal_ korrekt (als String) gespeichert wird.
    /// </summary>
    [Fact]
    public void PersistEnumInMealTest()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    /// <summary>
    /// _PersistEnumInMealOrderTest_ beweist, dass die Enum _OrderStatus_ in _MealOrder_ (als String) korrekt gespeichert wird.
    /// </summary>    
    [Fact]
    public void PersistEnumInMealOrderTest()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    /// <summary>
    /// _PersistValueObjectInSchoolTest_ beweist, dass Sie ein Entity vom Typ _School_ mit einer Adresse als value object speichern k�nnen.
    /// </summary>
    [Fact]
    public void PersistValueObjectInSchoolTest()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    /// <summary>
    /// _EnsureNameInSchoolIsUniqueTest_ beweist, dass Sie nur ein Entity vom Typ _School_ mit gleichem Namen speichern k�nnen.
    /// gelesen werden kann.
    /// </summary>
    [Fact]
    public void EnsureNameInSchoolIsUniqueTest()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    /// <summary>
    /// _EnsureShortnameInAllergenIsUniqueTest_ beweist, dass Sie nur ein Entity vom Typ _Allergen_ mit gleichem Shortname speichern k�nnen.
    /// </summary>
    [Fact]
    public void EnsureShortnameInAllergenIsUniqueTest()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    private MealContext GetEmptyDbContext()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new MealContext(options);
        db.Database.EnsureCreated();
        return db;
    }

}