﻿// *************************************************************************************************
// VORDEFINIERTE INTEGRATION TESTS ZUR AUTOMATISIERTEN KONTROLLE
// Hier ist nichts auszufüllen oder zu bearbeiten!
// Sie können die Tests zur Kontrolle ausführen, aber hier wird nichts implementiert.
// Bei der Kontrolle der Abgaben wird diese Datei durch die Originalversion ersetzt.
// *************************************************************************************************
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe3.Test;

[Collection("Sequential")]
public class Aufgabe3MasterTests : IClassFixture<TestWebApplicationFactory>
{
    private readonly TestWebApplicationFactory _factory;

    public Aufgabe3MasterTests(TestWebApplicationFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task T01_GetMembersWithoutFilterStatusOkTest()
    {
        _factory.SeedDatabase();
        var response = await _factory.Client.GetAsync("/fitness/members");
        Assert.True(response.StatusCode == HttpStatusCode.OK);
    }

    [Fact]
    public async Task T02_GetMembersWithoutFilterStatusOkWithDataTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/fitness/members");
        var expected = @"[{""id"":1,""firstName"":""Alice"",""lastName"":""Example"",""email"":""alice@example.com"",""membershipType"":""Premium""},{""id"":2,""firstName"":""Bob"",""lastName"":""Fit"",""email"":""bob@example.com"",""membershipType"":""Basic""},{""id"":3,""firstName"":""Charlie"",""lastName"":""Chill"",""email"":""charlie@example.com"",""membershipType"":""Basic""},{""id"":4,""firstName"":""Dora"",""lastName"":""Power"",""email"":""dora@example.com"",""membershipType"":""Premium""},{""id"":5,""firstName"":""Eli"",""lastName"":""Motion"",""email"":""eli@example.com"",""membershipType"":""Basic""}]";
        Assert.True(JsonElement.DeepEquals(data, JsonDocument.Parse(expected).RootElement));
    }

    [Fact]
    public async Task T03_GetMembersWithFilterStatusOkTest()
    {
        _factory.SeedDatabase();
        var response = await _factory.Client.GetAsync("/fitness/members?membershipType=Premium");
        Assert.True(response.StatusCode == HttpStatusCode.OK);
    }

    [Fact]
    public async Task T04_GetMembersWithFilterStatusOkWithDataTest()
    {
        _factory.SeedDatabase();
        var (status, data) = await _factory.GetHttpContent("/fitness/members?membershipType=Premium");
        var expected = @"[{""id"":1,""firstName"":""Alice"",""lastName"":""Example"",""email"":""alice@example.com"",""membershipType"":""Premium""},{""id"":4,""firstName"":""Dora"",""lastName"":""Power"",""email"":""dora@example.com"",""membershipType"":""Premium""}]";
        Assert.True(JsonElement.DeepEquals(data, JsonDocument.Parse(expected).RootElement));
    }


    [Fact]
    public async Task T05_DeleteMemberStatusNoContentTest()
    {
        _factory.SeedDatabase();
        var response = await _factory.Client.DeleteAsync("/fitness/member/1");
        Assert.True(response.StatusCode == HttpStatusCode.NoContent);
    }

    [Fact]
    public async Task T06_DeleteMemberStatusNoContentWithDataTest()
    {
        _factory.SeedDatabase();
        var response = await _factory.Client.DeleteAsync("/fitness/member/1");
        Assert.True(response.StatusCode == HttpStatusCode.NoContent);
        Assert.True(!_factory.QueryDatabase(db => db.Members.Any(m => m.Id == 1)));
    }
}
