﻿using System;
using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Meal
{
    // TODO: Add your implementation
}
