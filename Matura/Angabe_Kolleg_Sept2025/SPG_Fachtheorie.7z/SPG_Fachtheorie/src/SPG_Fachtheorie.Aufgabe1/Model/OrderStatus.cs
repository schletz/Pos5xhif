﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public enum OrderStatus
{
    // TODO: Add your implementation
}
