﻿using System.Collections.Generic;

namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Student
{
    // TODO: Add your implementation
}
