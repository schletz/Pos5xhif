﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public enum MealType
{
    // TODO: Add your implementation
}

