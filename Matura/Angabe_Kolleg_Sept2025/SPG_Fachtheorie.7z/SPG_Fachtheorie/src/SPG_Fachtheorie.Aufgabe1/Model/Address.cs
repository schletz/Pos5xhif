﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Address
{
    // TODO: Add your implementation
}


