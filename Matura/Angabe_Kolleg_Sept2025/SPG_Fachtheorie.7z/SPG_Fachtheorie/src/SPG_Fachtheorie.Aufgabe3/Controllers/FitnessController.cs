﻿#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe3.Dtos;

namespace SPG_Fachtheorie.Aufgabe3.Controllers;
[Route("[controller]")]
[ApiController]
public class FitnessController : ControllerBase
{
    private readonly FitnessContext _db;

    public FitnessController(FitnessContext db)
    {
        _db = db;
    }

    /// <summary>
    /// GET /fitness/members
    /// Liefert alle Mitglieder.
    /// Ist der Query Parameter membershipType nicht vorhanden oder leer, werden alle Mitglieder geliefert.
    /// Ist der membershipType gesetzt, wird das Feld Member.MembershipType mit dem Wert verglichen.
    /// 
    /// TODO: Add parameters for query parameter
    /// </summary>
    [HttpGet("members")]
    [ProducesResponseType<List<MemberDto>>(StatusCodes.Status200OK)]
    public async Task<ActionResult<List<MemberDto>>> GetMembers()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }


    // ================================
    // 2. DELETE: /fitness/member/{id}
    // ================================
    // TODO: Add parameters for routing parameter
    [HttpDelete("member/{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteMember()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }
}

#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously