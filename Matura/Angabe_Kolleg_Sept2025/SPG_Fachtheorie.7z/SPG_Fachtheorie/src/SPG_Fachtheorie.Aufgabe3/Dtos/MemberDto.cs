﻿namespace SPG_Fachtheorie.Aufgabe3.Dtos;

public record MemberDto(int Id, string FirstName, string LastName, string Email, string MembershipType);
