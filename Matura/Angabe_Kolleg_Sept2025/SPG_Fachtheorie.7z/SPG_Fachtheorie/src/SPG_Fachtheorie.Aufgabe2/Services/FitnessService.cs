﻿using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SPG_Fachtheorie.Aufgabe2.Services;

public class FitnessService
{
    public record ActiveMemberDto(int Id, string FirstName, string LastName, string Email);
    public record TrainingSessionWithCountDto(
        int Id, string RoomName, DateTime DateTime,
        string TrainerFirstName, string TrainerLastName, int ParticipantCount);
    public record MaxRatingCountPerTrainer(int Id, string FirstName, string LastName, int MaxRatingCount);


    private readonly FitnessContext _db;
    public FitnessService(FitnessContext db)
    {
        _db = db;
    }

    public List<ActiveMemberDto> GetActiveMembers()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    public List<TrainingSessionWithCountDto> GetTrainingSessionsWithParticipantCounts()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    public List<MaxRatingCountPerTrainer> GetMaxRatingCountPerTrainer()
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    public Participation RegisterMemberToTrainingSession(int memberId, int trainingSessionId)
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }

    public void UpdateRating(int memberId, int trainingSessionId, int rating)
    {
        // TODO: Add your implementation instead of throwing NotImplementedException.
        throw new NotImplementedException();
    }
}
