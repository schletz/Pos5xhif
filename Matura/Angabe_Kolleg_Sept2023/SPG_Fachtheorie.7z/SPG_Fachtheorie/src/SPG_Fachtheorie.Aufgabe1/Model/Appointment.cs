﻿using System;

namespace SPG_Fachtheorie.Aufgabe1.Model
{
    /// <summary>
    /// Der Termin des Patienten.
    /// </summary>
    public class Appointment
    {
    }
}