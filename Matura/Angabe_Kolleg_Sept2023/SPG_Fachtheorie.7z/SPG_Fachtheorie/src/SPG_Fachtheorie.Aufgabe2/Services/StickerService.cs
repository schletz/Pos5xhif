﻿using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe2.Infrastructure;
using SPG_Fachtheorie.Aufgabe2.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SPG_Fachtheorie.Aufgabe2.Services
{
    public record SaleStatistics(string StickerTypeName, decimal TotalRevenue);

    public class StickerService
    {
        private readonly StickerContext _db;

        public StickerService(StickerContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Checks the permission for a scanned numberplate.
        /// </summary>
        public bool HasPermission(string numberplate, DateTime dateTime, VehicleType carType)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Calculates the total revenue for every sticker type sold in a specific year.
        /// Use PurchaseDate.Year to get the year of purchase.
        /// Hint: To use Sum() you have to cast Price to double.
        ///       After that you have to cast the sum back to decimal.
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        public List<SaleStatistics> CalcSaleStatistics(int year)
        {
            throw new NotImplementedException();
        }
    }
}