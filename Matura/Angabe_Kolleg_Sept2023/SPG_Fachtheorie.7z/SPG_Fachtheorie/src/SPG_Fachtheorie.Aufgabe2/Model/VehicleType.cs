﻿namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public enum VehicleType
    { PassengerCar = 1, Motorcycle }
}