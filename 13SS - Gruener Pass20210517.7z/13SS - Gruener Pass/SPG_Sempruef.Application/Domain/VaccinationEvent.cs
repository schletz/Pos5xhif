﻿namespace SPG_Sempruef.Application.Domain
{
    public class VaccinationEvent : CoronaEvent
    {
        public string Vendor { get; set; }
    }

}
