﻿using System;

namespace SPG_Sempruef.Application.Domain
{
    public class CoronaEvent
    {
        public int Id { get; set; }
        public int PersonId { get; set; }
        public Person Person { get; set; }
        public DateTime Determined { get; set; }
    }

}
