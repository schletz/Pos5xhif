﻿using System;

namespace SPG_Sempruef.Application.Domain
{
    public class TestedEvent : CoronaEvent
    {
        public string EmsNumber { get; set; }
        public string TestStationNumber { get; set; }
        public DateTime ValidUntil { get; set; }
    }

}
