﻿using System;

namespace SPG_Sempruef.Application.Domain
{
    public class CuredEvent : CoronaEvent
    {
        public DateTime ValidUntil { get; set; }
    }

}
