﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Bogus;
using Bogus.Extensions;
using SPG_Sempruef.Application.Domain;

namespace SPG_Sempruef.Application.Infrastructure
{
    public class GreenCheckContext : DbContext
    {
        public DbSet<Domain.Person> Persons => Set<Domain.Person>();
        public DbSet<CoronaEvent> CoronaEvents => Set<CoronaEvent>();
        public DbSet<TestedEvent> TestedEvents => Set<TestedEvent>();
        public DbSet<CuredEvent> CuredEvents => Set<CuredEvent>();
        public DbSet<VaccinationEvent> VaccinationEvents => Set<VaccinationEvent>();
        public GreenCheckContext(DbContextOptions opt) : base(opt) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Domain.Person>().HasIndex(p => p.EcardId).IsUnique();
        }
        public void Seed()
        {
            Randomizer.Seed = new Random(2007);
            var persons = new Faker<Domain.Person>("de").Rules((f, p) =>
            {
                p.EcardId = f.Random.String2(10, "1234567890ABCDEF");
                p.Firstname = f.Name.FirstName();
                p.Lastname = f.Name.LastName();
                p.Email = f.Internet.Email();
                p.DateOfBirth = new DateTime(1950, 1, 1).AddDays(f.Random.Int(0, 50 * 365));
            })
            .Generate(10)
            .ToList();
            Persons.AddRange(persons);
            SaveChanges();

            var vendors = new string[] { "Astra Zeneca", "Biontech / Pfizer", "Moderna" };
            var vaccinatioEvents = new Faker<VaccinationEvent>("de").Rules((f, v) =>
            {
                v.Person = f.Random.ListItem(persons);
                v.Determined = new DateTime(2021, 4, 1).AddSeconds(f.Random.Int(0, 30 * 86400));
                v.Vendor = f.Random.ListItem(vendors);
            })
            .Generate(10);
            VaccinationEvents.AddRange(vaccinatioEvents);
            SaveChanges();

            var curedEvents = new Faker<CuredEvent>("de").Rules((f, c) =>
            {
                c.Person = f.Random.ListItem(persons);
                c.Determined = new DateTime(2021, 4, 1).AddSeconds(f.Random.Int(0, 30 * 86400));
                c.ValidUntil = c.Determined.AddMonths(6);
            })
            .Generate(10);
            CuredEvents.AddRange(curedEvents);
            SaveChanges();

            var testedEvents = new Faker<TestedEvent>("de").Rules((f, t) =>
            {
                t.Person = f.Random.ListItem(persons);
                t.Determined = new DateTime(2021, 4, 1).AddSeconds(f.Random.Int(0, 30 * 86400));
                t.EmsNumber = f.Random.String2(6, "1234567890ABCDEF");
                t.TestStationNumber = f.Random.String2(1, "WNB") + f.Random.Int(1000, 9999).ToString();
                t.ValidUntil = t.Determined.AddHours(48);

            })
            .Generate(10);
            TestedEvents.AddRange(testedEvents);
            SaveChanges();
        }
    }
}
