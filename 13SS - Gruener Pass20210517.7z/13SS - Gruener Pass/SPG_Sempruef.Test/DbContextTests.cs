using SPG_Sempruef.Application.Infrastructure;
using System;
using Xunit;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.IO;
using SPG_Sempruef.Application.Domain;

namespace SPG_Sempruef.Test
{
    public class DbContextTests
    {
        private GreenCheckContext GetContext()
        {
            var directory = new DirectoryInfo(Directory.GetCurrentDirectory());
            while (!directory.GetFiles("*.csproj").Any()) { directory = directory.Parent; }

            File.Copy(Path.Combine(directory.FullName, "GreenPass_Muster.db"),
                Path.Combine(directory.FullName, "GreenPass.db"),
                overwrite: true);
            var opt = new DbContextOptionsBuilder()
                .UseSqlite($"Data Source={Path.Combine(directory.FullName, "GreenPass.db")}")
                .Options;

            var db = new GreenCheckContext(opt);
            return db;
        }

        [Fact]
        public void CreateDatabaseTest()
        {
            var directory = new DirectoryInfo(Directory.GetCurrentDirectory());
            while (!directory.GetFiles("*.csproj").Any()) { directory = directory.Parent; }
            var opt = new DbContextOptionsBuilder()
                .UseSqlite($"Data Source={Path.Combine(directory.FullName, "GreenPass_Muster.db")}")
                .Options;

            using var db = new GreenCheckContext(opt);
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
            db.Seed();
        }


        [Fact]
        public void GetStateTest()
        {
            using var db = GetContext();
            var person = db.Persons.Include(p=>p.CoronaEvents).FirstOrDefault(p => p.EcardId == "4BAF683656");
            var coronaEvent = person.CoronaEvents
                .OrderByDescending(c => c.Determined)
                .FirstOrDefault();
            Assert.True(coronaEvent is CuredEvent);
        }
    }
}
