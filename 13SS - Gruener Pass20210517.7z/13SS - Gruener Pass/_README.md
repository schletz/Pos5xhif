# Semesterprüfung aus Programmieren und Software Engineering

Semester: V. Jahrgang Sommersemester  
Termin: 14. Mai 2021  
Beginn: 10:45  
Ende: 12:20

Wesentliche Kompetenzen lt. Lehrplan: *Komplexe, plattformübergreifende Softwaresysteme für den Produktivbetrieb erstellen.*

## Einführung

In den Medien wird intensiv über den "Grünen Pass" diskutiert. Es ist ein System, welches die
"epidemiologische Gefahr" mit Hilfe von 3 Informationen (vereinfacht) anzeigt:

- Geimpfte Personen (vaccinated) besitzen immer den Status "grün".
- Genesene Personen (cured) besitzen 6 Monate lang den Status "grün".
- Getestete Personen (tested) besitzen 48 Stunden lang den Status "grün".

Die Datenhaltung für das System wird in Form des folgenden Klassendiagramms realisiert:

```plantuml
@startuml


class CoronaEvent {
    Person : Person
    Determined : DateTime
}

class VaccinationEvent  {
    Vendor : String
}
VaccinationEvent --|> CoronaEvent

class CuredEvent {
    ValidUntil : DateTime
}
CuredEvent --|> CoronaEvent

class TestedEvent {
    EmsNumber : String
    TestStationNumber : String
    ValidUntil : DateTime
}
TestedEvent --|> CoronaEvent

class Person {
    EcardId : String
    Firstname : String
    Lastname : String
    Email : String
    DateOfBirth : DateTime
    CoronaEvents : List<CoronaEvent>
}
Person <--> CoronaEvent
@enduml
```

Im Musterprojekt ist bereits eine fertige Implementierung des Datenmodells samt EF Core
Datenbankkontext vorhanden. Es sind also keine Modelklassen zu erstellen.

## Plattformübergreifende REST Schnittstelle

### Arbeitsauftrag

Damit mehrere Systeme (auch auch EU Ebene) Daten abrufen und einfügen können, sollen Sie eine
REST Schnittstelle dafür entwickeln. Erstellen Sie eine Klasse *PersonController*, die folgende
Routen abbildet:

#### GET /api/person/{ecardId}

Gibt den aktuellen Status der übergebenen Person (*EcardId*) aus. Das Format ist unten angegeben.
Als Jahr wird das Jahr des Geburtsdatums verwendet.

Der State wird wie folgt ermittelt:

- *VACCINATED* wenn die Person eine eingetragene Impfung besitzt.
- *CURED* wenn die Person genesen ist. Dies wird jedoch nur gesetzt, wenn die Gültigkeit (*ValidUntil*) nicht überschritten ist. Verwenden Sie *DateTime.UtcNow* zum Prüfen dieses Datums.
- *TESTED* wenn die Person getestet wurde. Dies wird jedoch nur gesetzt, wenn die Gültigkeit (*ValidUntil*) nicht überschritten ist. Verwenden Sie *DateTime.UtcNow* zum Prüfen dieses Datums.

Ist ein Test oder eine Genesung abgelaufen, wird der State *EXPIRED* angegeben. Ist kein Status
bei der Person eingetragen (*CoronaEvents* sind leer), wird *UNKNOWN* angegeben.

```javascript
{
    "Firstname": "Max",
    "Lastname": "Mustermann",
    "Year": 2000,
    "State": "VACCINATED"
}
```

Hinweise:

- Erstellen Sie eine DTO Klasse für die Rückgabe der Daten.
- Mit Hilfe von `CoronaEvents.OrderByDescending(c=>c.Determined).FirstOrDefault()` können Sie das aktuellste Event der Person herausfinden. Achten Sie aber darauf, dass mit `Include(p=>p.CoronaEvents)` die Events aus der Datenbank geladen wurden. Die obigen Feststellungen werden auf Basis des letzten Events ermittelt.
- Verwenden Sie die C# Operatoren *is* bzw. *as*, um einen Typencast auf den entsprechenden Coronastatus durchzuführen.

Bewertet werden folgende Teilpunkte:

1. Der State *VACCINATED* wird korrekt ermittelt.
2. Der State *CURED* wird korrekt ermittelt.
3. Der State *TESTED* wird korrekt ermittelt.
4. Es existiert ein Unittest, mit dessen Hilfe eine Person mit dem State *VACCINATED* abgefragt und überprüft wird.
5. Es existiert ein Unittest, mit dessen Hilfe eine Person mit dem State *CURED* abgefragt und überprüft wird.
6. Es existiert ein Unittest, mit dessen Hilfe eine Person mit dem State *TESTED* abgefragt und überprüft wird.
7. Die Routing Annotation wurde korrekt gesetzt, sodass der Server die Route mit der angegebenen URL erreicht.

#### POST /api/person/vaccination

Fügt eine Impfung zur angegebenen Person ein. Im Request Body wird ein JSON Dokument mit folgendem
Aufbau mit übertragen:

```javascript
{
    "Determined" : "2021-05-11T14:30:20Z",
    "Vendor" : "Astra Zeneca"
}
```

Der Controller soll den eingefügten Personendatensatz mit Status HTTP 200 (OK) zurückliefern.
Wird die Person nicht gefunden, so wird HTTP 404 (not found) zurückgegeben.

Bewertet werden folgende Teilpunkte:

1. Die DTO Klasse für den Payload wurde korrekt erstellt.
2. Der Datensatz wird korrekt in die Datenbank eingefügt.
3. Der Controller liefert den korrekten Status und ein Personenobjekt.
4. Der Controller liefert HTTP 404, wenn eine Person nicht gefunden wird.
5. Es existiert ein Unittest, mit dessen Hilfe die korrekte Eintragung einer Impfung überprüft wird.
6. Es existiert ein Unittest, mit dessen Hilfe der Status 404 überprüft wird.
7. Die Routing Annotation wurde korrekt gesetzt, sodass der Server die Route mit der angegebenen URL erreicht.

#### POST /api/person/test

Fügt einen Test zur angegebenen Person ein. Im Request Body wird ein JSON Dokument mit folgendem
Aufbau mit übertragen:

```javascript
{
    "Determined" : "2021-05-11T14:30:20Z",
    "EmsNumber" : "A4307C1",
    "TestStationNumber" : "W014"
}
```

Die Gültigkeitsdauer (*ValidUntil*) berechnet sich nach der Formel *Determined* + 48 Stunden.
Hinweis: Verwenden Sie die Methode *AddHours()*.

Der Controller soll den eingefügten Personendatensatz mit Status HTTP 200 (OK) zurückliefern.
Wird die Person nicht gefunden, so wird HTTP 404 (not found) zurückgegeben.

Bewertet werden folgende Teilpunkte:

1. Die DTO Klasse für den Payload wurde korrekt erstellt.
2. Der Datensatz wird korrekt in die Datenbank eingefügt.
3. Das Datum der Gültigkeit wird korrekt ermittelt und eingetragen.
4. Der Controller liefert den korrekten Status und ein Personenobjekt.
5. Der Controller liefert HTTP 404, wenn eine Person nicht gefunden wird.
6. Es existiert ein Unittest, mit dessen Hilfe die korrekte Eintragung einer Impfung überprüft wird.
7. Es existiert ein Unittest, mit dessen Hilfe der Status 404 überprüft wird.
8. Die Routing Annotation wurde korrekt gesetzt, sodass der Server die Route mit der angegebenen URL erreicht.

## Erlaubte Hilfsmittel

Gelöstes Unterrichtsprojekt "Hotelverwaltung" ohne Kommentare, erreichbar unter der URL
*https://github.com/schletz/Pos5xhif/tree/master/Matura/Spg_Hotelmanager/Loesung*.

## Bewertung

Jede gelöste Teilaufgabe wird mit 1 Punkt bewertet. Die Gesamtbewertung wird wie folgt ermittelt:

Sehr gut: 22 - 20 Punkte  
Gut: 19 - 17 Punkte  
Befriedigend: 16 - 14 Punkte  
Genügend: 13 - 11 Punkte  
Nicht genügend: weniger  als 11 Punkte.
