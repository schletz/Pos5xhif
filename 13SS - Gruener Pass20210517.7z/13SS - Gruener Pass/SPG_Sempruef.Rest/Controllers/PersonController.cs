﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SPG_Sempruef.Application.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SPG_Sempruef.Rest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly GreenCheckContext _db;

        public PersonController(GreenCheckContext db)
        {
            _db = db;
        }

        [HttpGet("dbTest")]
        public IActionResult TestDatabase()
        {
            return Ok(_db.Persons.ToList());
        }
    }
}
